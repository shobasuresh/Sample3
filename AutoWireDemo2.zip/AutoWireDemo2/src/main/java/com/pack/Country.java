package com.pack;
import org.springframework.beans.factory.annotation.Autowired;

 
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

 
public class Country {


	String countryName;

	 
	 Capital  capital;
	
	 
	
	 
	public void setCapital(Capital capital) {
		this.capital = capital;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public Capital getCapital() {
		return capital;
	}
	
	 
	
	
	 
	 
}